/* screens1.jsx — Home, Inbox/Sent, Write, Detail (exported to window) */
const { useState: useState1, useEffect: useEffect1, useRef: useRef1 } = React;

/* ============================ HOME (此刻) ============================ */
function HomeScreen({ nav, moodDone, todayMood, onMoodSaved, dark, onToggleDark }) {
  const [editing, setEditing] = useState1(false);
  const top = MATCHES[0];
  const tiles = [
    { key: "write", icon: "✎", label: "写信", cls: "qt-1", go: () => nav("write", { targetNickname: top.profile.nickname, isFirst: true }) },
    { key: "inbox", icon: "✉", label: "信箱", cls: "qt-2", go: () => nav("inbox") },
    { key: "journey", icon: "❍", label: "旅程", cls: "qt-3", go: () => nav("journey") },
    { key: "match", icon: "☾", label: "推荐", cls: "qt-4", go: () => nav("match") },
  ];
  return (
    <div className="page">
      <StatusBar dark />
      <div className="page-scroll tab-fade">
        <div className="home-header">
          <div className="home-toprow">
            <div className="home-greeting">
              <div className="home-hello">晚上好，</div>
              <div className="home-name">{ME.nickname}<span className="seal-dot">🌙</span></div>
            </div>
            <button className={"theme-orb" + (dark ? " is-dark" : "")} onClick={onToggleDark} aria-label="切换深色模式">
              <span className="orb-glyph">{dark ? "☾" : "☀"}</span>
            </button>
            <Avatar name={ME.nickname} className="home-avatar" />
          </div>
          <div className="home-tagline">慢下来，好好说话 · 2026年6月4日 周四</div>
        </div>

        {/* 快捷入口 */}
        <div className="quick-tiles">
          {tiles.map((t) => (
            <div key={t.key} className={"quick-tile " + t.cls} onClick={t.go}>
              <span className="qt-icon">{t.icon}</span>
              <span className="qt-label">{t.label}</span>
            </div>
          ))}
        </div>

        {/* 今日心情 */}
        <div className="section">
          <div className="section-header">
            <span className="section-title ribbon"><span className="ribbon-banner"><span className="rb-mark">✶</span>此刻心情</span></span>
          </div>
          {!moodDone && (
            <div className="card fade-in">
              <div className="mood-prompt-title">今天，你怎么样？</div>
              <div className="mood-prompt-sub">记录此刻的心情</div>
              <MoodWidget onSave={onMoodSaved} />
            </div>
          )}
          {moodDone && !editing && (
            <div className="card fade-in">
              <div className="mood-done-row">
                <div className="mood-done-info">
                  <span className="mood-done-label">今日心情已记录</span>
                  {todayMood && <MoodBadge emotion={todayMood.emotion} label={todayMood.emotionLabel} withFace />}
                </div>
                <div className="mood-edit-btn" onClick={() => setEditing(true)}>修改</div>
              </div>
              {todayMood && todayMood.diary && <div className="mood-done-diary text-clamp-2">{todayMood.diary}</div>}
            </div>
          )}
          {moodDone && editing && (
            <div className="card fade-in">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span className="mood-prompt-title" style={{ fontSize: 18 }}>修改今日心情</span>
                <span style={{ fontSize: 13, color: "var(--color-ink-secondary)", cursor: "pointer" }} onClick={() => setEditing(false)}>取消</span>
              </div>
              <MoodWidget existing={todayMood} onSave={(m) => { onMoodSaved(m); setEditing(false); }} />
            </div>
          )}
        </div>

        {/* 今日灵魂推荐 — featured hero */}
        <div className="section" style={{ marginBottom: 0 }}>
          <div className="section-header">
            <span className="section-title ribbon"><span className="ribbon-banner"><span className="rb-mark">☾</span>今日灵魂</span></span>
            <span className="section-more" onClick={() => nav("match")}>全部 ›</span>
          </div>
        </div>
        <div className="featured-hero" onClick={() => nav("peer", { uid: top.profile._id })}>
          <div className="fh-label">今日最契合的灵魂</div>
          <div className="fh-row">
            <Avatar name={top.profile.nickname} className="fh-avatar" />
            <div>
              <div className="fh-name">{top.profile.nickname}</div>
              {top.profile.isActiveRecently && <div style={{ fontSize: 12, opacity: .82, fontFamily: "var(--font-serif)" }}>近期活跃</div>}
            </div>
            <div className="fh-score"><div className="num">{top.score}<span style={{ fontSize: 14 }}>%</span></div><span className="lbl">契合</span></div>
          </div>
          <div className="fh-intro text-clamp-2">{top.profile.intro}</div>
          <div className="fh-foot">
            <div className="fh-tags">{top.tagsCommon.map((t) => <span key={t} className="fh-tag">{t}</span>)}</div>
            <span className="fh-cta">写信给TA</span>
          </div>
        </div>

        {/* 去年的今天 */}
        <div className="section">
          <div className="section-header">
            <span className="section-title ribbon"><span className="ribbon-banner"><span className="rb-mark">❦</span>去年的今天</span></span>
            <span className="section-more" onClick={() => nav("journey")}>查看 ›</span>
          </div>
          <div className="card memory-card" onClick={() => nav("journey")}>
            <div className="memory-top">
              <span className="memory-year"><b>一年前</b><span className="dot" />2025年6月4日</span>
              <MoodBadge emotion={MEMORY_TODAY.emotion} label={MEMORY_TODAY.emotionLabel} />
            </div>
            <div className="memory-excerpt text-clamp-3">{MEMORY_TODAY.displayText}</div>
          </div>
        </div>

        {/* 最近来信 */}
        <div className="section" style={{ marginBottom: 24 }}>
          <div className="section-header">
            <span className="section-title ribbon"><span className="ribbon-banner"><span className="rb-mark">✉</span>最近来信</span></span>
            <span className="section-more" onClick={() => nav("inbox")}>信箱 ›</span>
          </div>
          {LETTERS.slice(0, 2).map((l) => (
            <EnvelopeCard key={l._id} letter={l} onClick={() => nav("detail", { id: l._id })} />
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================ INBOX / SENT (信箱) ============================ */
function InboxScreen({ nav }) {
  const [tab, setTab] = useState1("inbox");
  const list = tab === "inbox" ? LETTERS : SENT;
  return (
    <div className="page">
      <StatusBar />
      <div className="seg-tabs">
        <div className={"seg-tab" + (tab === "inbox" ? " active" : "")} onClick={() => setTab("inbox")}>收件箱</div>
        <div className={"seg-tab" + (tab === "sent" ? " active" : "")} onClick={() => setTab("sent")}>已发出</div>
      </div>
      <div className="page-scroll" style={{ padding: "12px 16px 24px" }} key={tab}>
        <div className="tab-fade">
          {list.length === 0 ? (
            <div className="empty-state">
              <span className="empty-icon">✉</span>
              <span>{tab === "inbox" ? "还没有来信" : "还没有发出过信件"}</span>
              <span className="empty-sub">{tab === "inbox" ? "去发现灵魂匹配吧" : "写下你的第一封信"}</span>
            </div>
          ) : list.map((l) => (
            <EnvelopeCard key={l._id} letter={l} sent={tab === "sent"}
              onClick={() => nav("detail", { id: l._id, sent: tab === "sent" })} />
          ))}
        </div>
      </div>
      <button className="fab" onClick={() => nav("write", { targetNickname: "归零", isFirst: true })}>✎</button>
    </div>
  );
}

/* ============================ WRITE (写信) ============================ */
function WriteScreen({ params, back, toast }) {
  const isFirst = params.isFirst;
  const required = isFirst ? 150 : 100;
  const [title, setTitle] = useState1("");
  const [content, setContent] = useState1("");
  const [sending, setSending] = useState1(false);
  const wc = countWords(content);
  const canSend = wc >= required;
  const pct = Math.min(100, (wc / required) * 100);

  function send() {
    if (!canSend || sending) return;
    setSending(true);
    setTimeout(() => { toast("信件已寄出 ✦"); back(); }, 700);
  }

  return (
    <div className="page is-overlay">
      <StatusBar dark />
      <NavBar title="写信" onBack={back} />
      <div className="recipient-bar">
        <span className="recipient-label">致：</span>
        <span className="recipient-name">{params.targetNickname || "请选择收信人"}</span>
      </div>
      <div className="page-scroll">
        <div className="letter-paper ruled">
          <input className="title-input" placeholder="信件标题（选填）" maxLength={30} value={title} onChange={(e) => setTitle(e.target.value)} />
          <div className="paper-divider" />
          <textarea className="content-textarea"
            placeholder={isFirst ? "写下你想对TA说的话吧（至少150字）" : "写下你的回信（至少100字）"}
            value={content} onChange={(e) => setContent(e.target.value)} />
          <div className="counter-bar">
            <span className={"counter-text " + (canSend ? "counter-ok" : "counter-warn")}>{wc} / {required} 字</span>
            {!canSend && wc > 0 && <span className="counter-text counter-warn">还需 {required - wc} 字</span>}
          </div>
        </div>
        <div className="counter-progress"><i style={{ width: pct + "%" }} /></div>
      </div>
      <div className="send-area">
        <div className={"seal-stamp" + (canSend ? " active" : " sealed")} onClick={send}>✦</div>
        <div className="send-right">
          <div className="btn btn-ghost" style={{ padding: "11px 16px" }} onClick={() => toast("草稿已保存")}>存草稿</div>
          <div className={"btn btn-primary" + (!canSend || sending ? " btn-disabled" : "")} onClick={send}>{sending ? "寄出中..." : "封存寄出"}</div>
        </div>
      </div>
    </div>
  );
}

/* ============================ DETAIL + OPEN ANIMATION ============================ */
function OpenAnimation({ onDone, speed }) {
  const [stage, setStage] = useState1(0);
  const startedRef = useRef1(false);
  function play() {
    if (startedRef.current) return;
    startedRef.current = true;
    const s = speed || 1;
    setStage(1);
    setTimeout(() => setStage(2), 120 * s);
    setTimeout(() => setStage(3), 380 * s);
    setTimeout(() => onDone(), 1150 * s);
  }
  return (
    <div className="open-anim" data-stage={stage} onClick={play}>
      <div className="open-hint">{stage === 0 ? "轻触信封 · 拆开来信" : "正在拆信…"}</div>
      <div className="envelope-3d">
        <div className="env-base" />
        <div className="env-letter"><div className="scribble"><i/><i/><i/><i/></div></div>
        <div className="env-flap" />
        <div className="env-wax"><div className="seal-stamp active" style={{ width: 48, height: 48, fontSize: 19 }}>平</div></div>
      </div>
    </div>
  );
}

function DetailScreen({ params, nav, back, speed }) {
  const sent = params.sent;
  const src = sent ? SENT : LETTERS;
  const letter = src.find((l) => l._id === params.id) || LETTERS[0];
  const wasUnread = !sent && letter.status === "sent";
  const [done, setDone] = useState1(!wasUnread);
  const name = sent ? letter.receiverNickname : letter.senderNickname;

  return (
    <div className="page is-overlay">
      <StatusBar dark />
      <NavBar title={sent ? "已寄出" : "来信"} onBack={back} />
      {!done ? (
        <OpenAnimation onDone={() => setDone(true)} speed={speed} />
      ) : (
        <React.Fragment>
          <div className="page-scroll">
            <div className="detail-sender fade-in" onClick={() => !sent && nav("peer", { uid: letter.from_uid })}>
              <Avatar name={name} />
              <div>
                <div className="sender-name">{sent ? "致 " + name : name}</div>
                <div className="sender-time">{letter.timeDisplay}</div>
              </div>
              {!sent && <span className="sender-arrow">›</span>}
            </div>
            <div className="read-paper fade-in">
              {letter.title && <div className="read-title">{letter.title}</div>}
              <div className="read-body">{letter.content}</div>
              <div className="read-sign">— {name}，于平常</div>
            </div>
            <div style={{ height: 12 }} />
          </div>
          {!sent && (
            <div className="action-bar">
              <div className="btn btn-ghost" onClick={() => nav("write", { targetNickname: name, isFirst: false })}>归档</div>
              <div className="btn btn-primary" onClick={() => nav("write", { targetNickname: name, isFirst: false })}>回信</div>
            </div>
          )}
        </React.Fragment>
      )}
    </div>
  );
}

Object.assign(window, { HomeScreen, InboxScreen, WriteScreen, DetailScreen, OpenAnimation });
